export default {
  stuff: []
};