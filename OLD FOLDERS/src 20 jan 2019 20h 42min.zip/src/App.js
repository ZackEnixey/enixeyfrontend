import React, { Component } from 'react';
import StuffList from './components/stuffList';
import FrontPage from './components/frontPage/FrontPage';
import OpenedBook from './components/openedBook/OpenedBook';

/* development */
import Dashboard from './components/dashboard/Dashboard';
/* development */

import './App.css';

class App extends Component {
    render() {
        return (
            <div id="appWrapper" className="app">
                <OpenedBook />               
            </div>
        );
    }
}

export default App;