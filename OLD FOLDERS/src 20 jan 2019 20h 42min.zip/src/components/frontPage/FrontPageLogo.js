import React, { Component } from 'react';
import logoImage from'../images/logoEnixey.png';

var browserHeightGlobal = '700px';
class FrontPageLogo extends Component {

	constructor(props) {
	    super(props);
	    this.state = {
		    browserHeight: '700px',
		    color: 'white'
	    };
	    this.switchComponent = this.switchComponent.bind(this);
	 }

	switchComponent() {
		this.props.switchComponent("text")
	}

    render() {
    	browserHeightGlobal = document.documentElement.clientHeight;


    	//DragFromDB - Drag this from DATA-BASE 
    	var items = [
    		{'id': '0', 'title': 'First book', 'subtitle': 'The world of fairy tails', 'image': 'https://occ-0-1489-1490.1.nflxso.net/dnm/api/v5/rendition/412e4119fb212e3ca9f1add558e2e7fed42f8fb4/AAAABcs_3xuxkz7jRgXoBrO3vgNTRWUCE4PDrSfo4Us0It8pJ8e73dt-DFhl1k-8sfY94C7nd1vGHgmZ3FHvcV8oA3AOyjj1iM6rxxyWVSzO0HjbG0mQG428CBPnY8v-sKZr_VFVeq3Pe8o.webp'},
		   	{'id': '1', 'title': 'Second book', 'subtitle': 'Dive into an adventure', 'image': 'https://occ-0-1489-1490.1.nflxso.net/dnm/api/v5/rendition/412e4119fb212e3ca9f1add558e2e7fed42f8fb4/AAAABfGQw6Ok_qNJ5FyR2u0BhNBEZj1LO1HVPT6bH8svmvF1wfSPtOe9Mb_MXSHR7_6OH7H_ny_Gbp-_InEqI2YfNpPoIQOrOHhfQ14iHYrk4PTtnN9amMd4olvKm2awD9mLkE8wW_NFoh4.webp'},
		   	{'id': '2', 'title': 'Third book', 'subtitle': 'Explore this world or', 'image': 'https://occ-0-1489-1490.1.nflxso.net/dnm/api/v5/rendition/412e4119fb212e3ca9f1add558e2e7fed42f8fb4/AAAABZlrMJGr3JjCFVtsA5rZAT27uXCTN-c7-pXkywr7hZmaU8eY_VYKFJB3GCE50D6qnmhuda_Rw12cgeAtPdF6rLvEvlX3V2nksfsHOksBjX3SjJ1ZPIE1UtPB-RT8vTNiM3EkxSB2csE.webp'},
		   	{'id': '3', 'title': 'Forth book', 'subtitle': 'Let us discover', 'image': 'https://occ-0-1489-1490.1.nflxso.net/dnm/api/v5/rendition/412e4119fb212e3ca9f1add558e2e7fed42f8fb4/AAAABVJh8QrJo7gI4kozh-c2rCeTgswE2JaxUk5ljMJlf597A3tA-g29Lzr_P2W1QUsOba33KVGV1uBkpmPaZwx3IEcgb2hxd731T_GHOZ6cJjcjoHus4kdOuCTvyrwDp5eZXx_Yba1cbs0.webp'},
		    {'id': '4', 'title': 'Fifth book', 'subtitle': 'This is a story of', 'image': 'https://occ-0-1489-1490.1.nflxso.net/dnm/api/v5/rendition/412e4119fb212e3ca9f1add558e2e7fed42f8fb4/AAAABZiiSVls7b12TKOzJfBn3HDprFyt_NnEki9-JSJXRlF-dEHpiPIQf-L-NnDy8CXE0OmHR80DrPd-4PREkBxzGLUu5f7ZvjuET9Cu3G0-Eco6jkfxQP3H2leLXnjATyHjXPn_7lQT-yQ.webp'},
		    {'id': '5', 'title': 'Sixth book', 'subtitle': 'One more time', 'image': 'https://occ-0-1489-1490.1.nflxso.net/dnm/api/v5/rendition/412e4119fb212e3ca9f1add558e2e7fed42f8fb4/AAAABY259ZMFcqMKsNmtiA7LnQJrN1b9WyMuAMGqUNWw_p9onw4Ae8k_QhwYKJ4zki1X7lIwUJQTsghorRQK75rEgveWXCtdntoUwWKGi7kiBs9YlI8sf7YAhT7OTYtyn0oDnJvSpVDldA.jpg'},
		    {'id': '6', 'title': 'Seventh book', 'subtitle': 'There is no end of', 'image': 'https://occ-0-1489-1490.1.nflxso.net/dnm/api/v5/rendition/412e4119fb212e3ca9f1add558e2e7fed42f8fb4/AAAABZlrMJGr3JjCFVtsA5rZAT27uXCTN-c7-pXkywr7hZmaU8eY_VYKFJB3GCE50D6qnmhuda_Rw12cgeAtPdF6rLvEvlX3V2nksfsHOksBjX3SjJ1ZPIE1UtPB-RT8vTNiM3EkxSB2csE.webp'},
		    {'id': '7', 'title': 'Eighth book', 'subtitle': 'If you think you know', 'image': 'https://occ-0-1489-1490.1.nflxso.net/dnm/api/v5/rendition/412e4119fb212e3ca9f1add558e2e7fed42f8fb4/AAAABcs_3xuxkz7jRgXoBrO3vgNTRWUCE4PDrSfo4Us0It8pJ8e73dt-DFhl1k-8sfY94C7nd1vGHgmZ3FHvcV8oA3AOyjj1iM6rxxyWVSzO0HjbG0mQG428CBPnY8v-sKZr_VFVeq3Pe8o.webp'},
		    {'id': '8', 'title': 'Ninth book', 'subtitle': 'The end is near so', 'image': 'https://occ-0-1489-1490.1.nflxso.net/dnm/api/v5/rendition/412e4119fb212e3ca9f1add558e2e7fed42f8fb4/AAAABfGQw6Ok_qNJ5FyR2u0BhNBEZj1LO1HVPT6bH8svmvF1wfSPtOe9Mb_MXSHR7_6OH7H_ny_Gbp-_InEqI2YfNpPoIQOrOHhfQ14iHYrk4PTtnN9amMd4olvKm2awD9mLkE8wW_NFoh4.webp'} 
		]


    	let rows = items.map( item => { 
			return( 
				<div id="frontPageScrollingBottomAd" className="frontPageScrollingBottomAd floatingTextParent" > 
					<div className="floatingTextChild floatingTextChildCoordinatesAd widthHeightHunderdPercent adText fontFamily"> 
						<div id="floatingTextTitle"> {item.title} </div> 
						<div id="floatingTextSubtitle"> {item.subtitle} </div> 
					</div>
					<img id="frontPageScrollingBottomAdImage" src={item.image} />
				</div>
			)
		})

        return (
            <div id="frontPageWrapper">

            	<div className="frontPageBackgroundColor" style={{"height": browserHeightGlobal}}>
	            	<div id="frontPageLogoImageWrapper" style={{"paddingTop": "200px"}} className="floatingTextParent" onClick={this.switchComponent} >
	            		<div id="frontPageLogIn" className="frontPageLogIn floatingTextChild floatingTextChildCoordinatesLogIn logInSignUpDimentions fontFamily"> 
	            			Log in/Sign up
	            		</div>

	            		<img id="frontPageLogoImage" className="centerImageInsideOfDiv frontPageLogoDimension" src={logoImage} />
	            	</div>
	            </div>

	            <div id="frontPageScrollingBottomAdWrapper" className="frontPageScrollingBottomAdWrapper">
	            	{rows}
	            </div>

            </div>
        );
    }
}

export default FrontPageLogo;