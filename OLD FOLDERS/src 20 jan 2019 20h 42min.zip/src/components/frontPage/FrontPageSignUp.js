import React, { Component } from 'react';

let listOfUsers = [ 
	{'username': 'demo', 'password': 'demo'},
	{'username': 'Zack', 'password': 'Zack'},
	{'username': 'Enixey', 'password': 'Enixey'},
	{'username': 'abba', 'password': 'abba'},
]

class FrontPageSignUp extends Component {

	constructor(props) {
	    super(props);
	    this.state = {
		    browserHeight: '700px',
		    userName: '',
		    password: '',
		    currentMode: 'signUp',
	    };
	    this.switchComponent = this.switchComponent.bind(this);	
	    this.handleChange = this.handleChange.bind(this);
    	this.handleSubmit = this.handleSubmit.bind(this);
	}

	switchComponent() {
		this.props.switchComponent("text")
	}

	handleChange(event) {
		console.log(event);
		if(event.target.name === 'password'){
			this.setState({ password: event.target.value });
		}else{
			this.setState({ userName: event.target.value });
		}
	}

	handleSubmit(event) {
		let inputedUserName = '';
		let inputedPassword = '';
		let defaultValue = event.target[2].defaultValue;

		alert(defaultValue);
		if(defaultValue === 'SIGN UP'){
			this.signUp(inputedUserName, inputedPassword);
		}else{ 
			this.logInCheck(event, inputedUserName, inputedPassword);
		}
	}

	signUp(inputedUserName, inputedPassword){
		// SERVER FUNCTIONALITY
		// add new user.
		listOfUsers.push({'username': inputedUserName, 'password': inputedPassword});
	}

	logInCheck(event, inputedUserName, inputedPassword){
		let existingUser;

		for(let i=0; i<event.target.length; i++){
			if(event.target[i].name === 'username'){
				inputedUserName = event.target[i].value;
			}else if(event.target[i].name === 'password'){
				inputedPassword = event.target[i].value;
			}
		}

		// SERVER FUNCTIONALITY
		existingUser = listOfUsers.find(o => o.username === inputedUserName);

		if(existingUser !== undefined){
	    	alert('username exists in database');
	    	if(existingUser.password !== inputedPassword){
	    		alert("username and Password DO NOT MATCH!");
	    	}else{
	    		alert("Username and password match!");
	    	}
		}else{
			alert(inputedUserName + " username does not exist");
			this.setState({
				currentMode: 'signUp'
			})
		}
	}

    render() {
        return ( 
            <div id="frontPageWrapper" >
	          		
            	<div className="center positioningParentDiv" >

            		<div className="signUpSquaresDimentions positioningChildDiv">
            			<form id="logInInputForm" onSubmit={this.handleSubmit} className="logInForm">
					        <label>
					          	<div className="logInInputFormText"> Username: </div>
					          	<div> <input className="logInInputForm" type="text" name="username" value={this.state.userName} onChange={this.handleChange} /> </div>
					        	<div className="logInInputFormText"> Password: </div>
					          	<div> <input className="logInInputForm" type="text" name="password" value={this.state.password} onChange={this.handleChange} /> </div>
					        </label>
					        {this.state.currentMode === 'logIn' ?
					        	<input id="logInInputFormButton" type="submit" value="LOG IN" className="logInInputFormButton webAppGreenColorForBackground" />
					        	:
					        	<input id="signUpInputFormButton" type="submit" value="SIGN UP" className="logInInputFormButton webAppGreenColorForBackground" />
					        }
					      </form>
            		</div>

            		<div onClick={this.switchComponent} className="signUpSquaresDimentions positioningChildDiv backgroundColorBlue signUpText fontFamily">
	            		{this.state.currentMode === 'logIn' ? 
		            		<div className="logInForm">
		            			<div className="logInTextTitle"> Enixey </div>
		            			<div className="marginTopTen"> The WebApp for privatisation of vocabulary. Learn what matters, study pragmatically! </div>
	      				        <div className="marginTopTen"> Don't have an account? Do not hessitate, make one right now. </div>
	      				        <input id="logInInputFormButton" type="submit" value="SIGN UP" className="logInInputFormButton webAppWhiteColorForBackground" />
		            		</div>
		            		:
		            		<div className="logInForm">
		            			<div className="logInTextTitle"> Enixey </div>
		            			<div className="marginTopTen"> The WebApp for privatisation of vocabulary. Learn what matters, study pragmatically! </div>
	      				        <div className="marginTopTen"> Don't look any further, this will make the most out of your studies! Boost your words absorbtion to the maximum. </div>
		            		</div>
	            		}
            		</div>

            	</div>

            </div>
        );
    }
}

export default FrontPageSignUp;