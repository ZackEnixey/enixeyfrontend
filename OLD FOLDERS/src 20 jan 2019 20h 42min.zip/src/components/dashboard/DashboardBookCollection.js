import React, { Component } from 'react';
import settingsIcon from '../images/settingsIcon.png';

class DashboardBookCollection extends Component {

	constructor(props) {
	    super(props);
	    this.state = {
		    browserHeight: '700px',
		    currentHeight: document.documentElement.clientHeight,
	    };
	    this.resize = this.resize.bind(this);
	}

	resize() {
    	this.setState({
    		currentHeight: document.documentElement.clientHeight
    	})
	}

	componentDidMount() {
		window.addEventListener('resize', this.resize)
		console.log('did');
	}

	componentWillUnmount() {
	  	window.removeEventListener('resize', this.resize)
	  	console.log('will');
	}

    openSelectedBook(item){
        alert(item.title);
    }

    render() {

    	var items = [
    	    {'id': '0', 'state': 'A', 'property': 'default', 'title': 'Zero book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1345958969l/128029.jpg'},
    		{'id': '1', 'state': 'A', 'property': 'default', 'title': 'First book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1361039443l/41865.jpg'},
    		{'id': '1', 'state': 'A', 'property': 'default', 'title': 'second book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1353048590l/6334.jpg'},
    		{'id': '2', 'state': 'A', 'property': 'default', 'title': 'third book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1451554970l/17333223.jpg'},
    		{'id': '3', 'state': 'A', 'property': 'default', 'title': 'forth book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1507963312l/33574273.jpg'},
    		{'id': '4', 'state': 'A', 'property': 'default', 'title': 'fifth book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1546091617l/15823480.jpg'},
    		{'id': '5', 'state': 'A', 'property': 'default', 'title': 'sixth book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1405259930l/18774964.jpg'},
    		{'id': '6', 'state': 'A', 'property': 'default', 'title': 'seventh book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1369504683l/10917.jpg'},
    		{'id': '7', 'state': 'A', 'property': 'default', 'title': 'eight book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1529026760l/39832183.jpg'},
    		{'id': '8', 'state': 'A', 'property': 'default', 'title': 'ninth book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1338822317l/13526165.jpg'},
    		{'id': '9', 'state': 'A', 'property': 'default', 'title': 'tenth book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1386925078l/11486.jpg'},
    		{'id': '10', 'state': 'A', 'property': 'default', 'title': 'e book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1411852091l/24280.jpg'},
    		{'id': '11', 'state': 'A', 'property': 'default', 'title': 'a book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1346267826l/40440.jpg'},
    		{'id': '12', 'state': 'A', 'property': 'default', 'title': '67 book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1451442088l/24817626.jpg'},
    		{'id': '13', 'state': 'A', 'property': 'default', 'title': '2 book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1475695315l/18045891.jpg'},
    		{'id': '14', 'state': 'A', 'property': 'default', 'title': '3 book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1360095966l/11125.jpg'},
    		{'id': '15', 'state': 'A', 'property': 'default', 'title': '4 book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1519203520l/36336078.jpg'},
    		{'id': '16', 'state': 'A', 'property': 'default', 'title': '5 book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1371850438l/13069935.jpg'},
    		{'id': '17', 'state': 'A', 'property': 'default', 'title': '6 book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1462088577l/26156987.jpg'},
    		{'id': '18', 'state': 'A', 'property': 'default', 'title': '7 book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1358748500l/6988014.jpg'},
    		{'id': '19', 'state': 'A', 'property': 'default', 'title': 'First book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1298411339l/34.jpg'},
    		{'id': '20', 'state': 'A', 'property': 'default', 'title': 'l book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1325861570l/170448.jpg'},
    		{'id': '21', 'state': 'A', 'property': 'default', 'title': 'k book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1537230024l/41574593.jpg'},
    		{'id': '22', 'state': 'A', 'property': 'default', 'title': 'j book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1474154022l/3.jpg'},
    		{'id': '23', 'state': 'A', 'property': 'default', 'title': 'h book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1447303603l/2767052.jpg'},
    		{'id': '24', 'state': 'A', 'property': 'default', 'title': 'fg book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1546091617l/15823480.jpg'},
    		{'id': '25', 'state': 'A', 'property': 'default', 'title': 'ad book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1405259930l/18774964.jpg'},
    		{'id': '26', 'state': 'A', 'property': 'default', 'title': 'f book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1369504683l/10917.jpg'},
    		{'id': '27', 'state': 'A', 'property': 'user', 'title': 'e book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1529026760l/39832183.jpg'},
    		{'id': '28', 'state': 'A', 'property': 'user', 'title': 'de book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1338822317l/13526165.jpg'},
    		{'id': '29', 'state': 'A', 'property': 'user', 'title': 'd book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1386925078l/11486.jpg'},
    		{'id': '30', 'state': 'A', 'property': 'user', 'title': 'c book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1411852091l/24280.jpg'},
    		{'id': '31', 'state': 'A', 'property': 'user', 'title': 'b book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1346267826l/40440.jpg'},
    		{'id': '32', 'state': 'A', 'property': 'user', 'title': 'a book', 'subtitle': 'The world of fairy tails', 'image': 'https://images.gr-assets.com/books/1451442088l/24817626.jpg'},
		]

		let rows = items.map( item => { 
			console.log("one")
			return( 		
				<div className="dashboardBookWrapper" onClick={() => this.openSelectedBook(item)}>
					 <img id="frontPageLogoImage" className="dashboardBook" src={item.image} />
				</div>			
			)
		})

		console.log(this.state.currentHeight);

		let dashboardHeight = this.state.currentHeight-99;

		return( 
			<div id="dashboardBookCollectionComponentWrapper" > 
				<div id="mainDashboardWrapper" className="mainDashboardWrapper" style={{"height": dashboardHeight }}>
					{rows}
				</div>
			</div>
		)
    }
}

export default DashboardBookCollection;