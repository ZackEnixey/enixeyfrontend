import React, { Component } from 'react';
import Header from '../header/Header';
import SubHeader from '../header/SubHeader';
import DashboardBookCollection from './DashboardBookCollection';
import settingsIcon from '../images/settingsIcon.png';
import profilePhoto from '../images/profilePhoto.png';
import readingIcon from '../images/readingIcon.png';
import wordListIcon from '../images/wordListIcon.png';
import dropDownIcon from '../images/dropDownIcon.png';
import hamburgerMenuIcon from '../images/hamburgerMenuIcon.png';
import demoIcon from '../images/demoIcon.png';

class Dashboard extends Component {

	constructor(props) {
	    super(props);
	    this.state = {
		    browserHeight: '700px',
	    };
	    this.headerMenuItemAction = this.headerMenuItemAction.bind(this);
	}

	headerMenuItemAction(what){
		console.log(what);
	}

	toggleWoleScreenDropDownMenu(){
		var x = document.getElementById("dropdown-content");
		if (x.style.display === "block" ) {
			x.style.display = "none";
		}else if(x.style.display === "none" ) {
			x.style.display = "block";
		}else{
			x.style.display = "block";
		}
	}

	closeDropDownMenu(){
		var x = document.getElementById("dropdown-content");
		x.style.display = "none";
	}

    render() {
		return( 
			<div id="dashboardComponent" > 
				<div id="headerDivWrapper"> 
					<Header toggleWoleScreenDropDownMenu={this.toggleWoleScreenDropDownMenu} /> 
				</div>         
                <div id="subHeaderDivWrapper" onClick={this.closeDropDownMenu} > 
                	<SubHeader />
                </div>
                <div id="dashboardDivWrapper" className="dashboardDivWrapper" onClick={this.closeDropDownMenu}> 
               		<DashboardBookCollection />
               	</div>

               	{ document.documentElement.clientWidth <= 600 ?
               		<div id="dropDownWrapper" className="dropDownWrapper">
		               	<div id="dropdown-content" className="dropdown-content">
									
							<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
								<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={settingsIcon} /> <div className="headerDropDownText">settings</div> 
							</div>
							<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
								<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={profilePhoto} /> <div className="headerDropDownText">profile</div>
							</div>
							<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
								<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={readingIcon} /> <div className="headerDropDownText">reading</div>
							</div>
							<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
								<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={wordListIcon} /> <div className="headerDropDownText">word list</div>
							</div>

							<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
								<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={demoIcon} /> <div className="headerDropDownText">users</div>
							</div>
							<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
								<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={demoIcon} /> <div className="headerDropDownText">statistics</div>
							</div>
							<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
								<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={demoIcon} /> <div className="headerDropDownText">news</div>
							</div>
							<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
								<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={demoIcon} /> <div className="headerDropDownText">recomendations</div>
							</div>
					
						</div>
					</div>
					:
					<div>
					</div>
				}

			</div>
		)
    }
}

export default Dashboard;