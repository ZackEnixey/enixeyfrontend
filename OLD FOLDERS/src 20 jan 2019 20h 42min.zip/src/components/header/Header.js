import React, { Component } from 'react';
import HeaderMenu from './HeaderMenu';
import SearchForm from './SearchForm';
import logoFlatImage from'../images/flatLogoEnixey.png';

class Header extends Component {

	constructor(props) {
	    super(props);
	    this.state = {
		    browserHeight: '700px',
		    mode: '',
	    };
	    this.resize = this.resize.bind(this);
	    this.headerMenuItemAction = this.headerMenuItemAction.bind(this);
	}


	resize() {
		if(document.documentElement.clientWidth <= 600){ 
	    	if(this.state.mode !=='small'){ 
		    	console.log('small ' + document.documentElement.clientWidth);
		    	this.forceUpdate();
		    }
	    }

	    if(document.documentElement.clientWidth > 600){ 
	    	if(this.state.mode !=='big'){ 
		    	console.log('big ' + document.documentElement.clientWidth);
		    	this.forceUpdate();
		    }		
	    }
	}

	componentDidMount() {
		window.addEventListener('resize', this.resize)
		console.log('did');
	}

	componentWillUnmount() {
	  	window.removeEventListener('resize', this.resize)
	  	console.log('will');
	}

	headerMenuItemAction(what){
		this.closeDropDownMenu();
		console.log(what);
	}

	closeDropDownMenu(){
		var x = document.getElementById("dropdown-content");
		x.style.display = "none";
	}

    render() {

    	if(document.documentElement.clientWidth > 600){ 
			return( 
				<div id="headerComponentWrapper" className="header" > 
					<div className="headerComponents headerLogoWidth" onClick={() => this.headerMenuItemAction('logo')} > <img id="frontPageLogoImage" className="headerLogoImage cursorPointer" src={logoFlatImage} /> </div>
					<div className="headerComponents headerSearchWidth" onClick={() => this.closeDropDownMenu()} > <SearchForm mode={'big'}/> </div> 
					<div className="headerComponents headerMenuWidth" > <HeaderMenu mode={'big'}/> </div>
				</div>
			)
		}else{
			return( 
				<div id="headerComponentWrapper" className="header"> 
					<div className="headerComponents  headerLogoWidthSmall" onClick={() => this.headerMenuItemAction('logo')}> <img id="frontPageLogoImage" className="headerLogoImage cursorPointer" src={logoFlatImage} /> </div>
					<div className="headerComponents  headerSearchWidthSmall" > <SearchForm mode={'small'} /> </div> 
					<div className="headerComponents  headerMenuWidthSmall" > <HeaderMenu mode={'small'} toggleWoleScreenDropDownMenu={this.props.toggleWoleScreenDropDownMenu} /> </div>
				</div>
			)
		}
    }
}

export default Header;