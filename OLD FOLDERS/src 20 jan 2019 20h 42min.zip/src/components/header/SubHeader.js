import React, { Component } from 'react';
import addNewItem from'../images/addNewItem.png';

class SubHeader extends Component {

	constructor(props) {
	    super(props);
	    this.state = {
		    browserHeight: '700px',
	    };
	    this.headerMenuItemAction = this.headerMenuItemAction.bind(this);
	}

	headerMenuItemAction(what){
		console.log(what);
	}

    render() {
		return( 
			<div id="subHeaderComponentWrapper" className="subheader"> 
				<div onClick={() => this.headerMenuItemAction('headerMenuDropDown')} > <img id="dashboardPlusIcon" className="addNewItemStyle circleOnProfilePhoto" src={addNewItem} /> </div>
			</div>
		)
    }
}

export default SubHeader;