import React, { Component } from 'react';

var items = [
    {'searchId': 'Stephenie Mayer Twilight', 	 'type': 'book',  	 'title': 'Twilight', 		'subtitle': 'whtie hand', 'url': 'reading/twilight', 	'icon': 'some/path/or/url.com'},
    {'searchId': 'J K rowling Harry Potter', 	 'type': 'book', 	 'title':'Harry Potter', 	'subtitle': 'wise stone', 'url': 'reading/harrypotter', 'icon': 'some/path/or/url.com'},
    {'searchId': 'Zack Enixey',  				 'type': 'user', 	 'title': 'Zack J Enixey', 	'subtitle': '', 		  'url': 'reading/zackJEnixey', 'icon': 'some/path/or/url.com'},
    {'searchId': 'Marc Marc', 	 				 'type': 'user', 	 'title': 'Marc Marc', 		'subtitle': '', 		  'url': 'reading/MarcMarc991', 'icon': 'some/path/or/url.com'},
    {'searchId': 'Anna Karenina',				 'type': 'book', 	 'title': 'Anna Karenina',  'subtitle': '', 		  'url': 'reading/annakarenina','icon': 'some/path/or/url.com'},
    {'searchId': 'Dashboard', 	 				 'type': 'component','title': 'Dashboard',		'subtitle': '', 		  'url': 'reading/dashboard', 	'icon': 'some/path/or/url.com'},
    {'searchId': 'The color Purple Alice Walker','type': 'book',  	 'title': 'Twilight', 		'subtitle': 'whtie hand', 'url': 'reading/twilight', 	'icon': 'some/path/or/url.com'},
    {'searchId': 'Victor Hugo Le Miserables', 	 'type': 'book', 	 'title': 'Harry Potter', 	'subtitle': 'wise stone', 'url': 'reading/harrypotter', 'icon': 'some/path/or/url.com'},
    {'searchId': 'Dan Brown Digital Fortres',    'type': 'book', 	 'title': 'Digital World',	'subtitle': '', 		  'url': 'reading/zackJEnixey', 'icon': 'some/path/or/url.com'},
    {'searchId': 'David Marchovich', 	 		 'type': 'user', 	 'title': 'David Marchovic','subtitle': '', 		  'url': 'reading/MarcMarc991', 'icon': 'some/path/or/url.com'},
    {'searchId': 'Dartagnan Victorious',		 'type': 'user', 	 'title': 'Dartagnan Vic',  'subtitle': '', 		  'url': 'reading/annakarenina','icon': 'some/path/or/url.com'},
    {'searchId': 'Angela merkel', 	 			 'type': 'user',	 'title': 'Angela Merkel', 	'subtitle': '', 		  'url': 'reading/dashboard', 	'icon': 'some/path/or/url.com'},
]
class SearchForm extends Component {

	constructor(props) {
	    super(props);
	    this.state = {
		    browserHeight: '700px',
		    name: '',
		    inputedValue: '',
		    showSearchDropdown: false,
      		shareholders: [{ name: '' }],
	    };
	 }

	handleNameChange = (evt) => {
	    var inputedValue = evt.target.value;
	    console.log(inputedValue);

	    this.setState({
	    	inputedValue: inputedValue,
	    	showSearchDropdown: true
	    })

	    // SERVER FUNCTIONALITY - getting PROCESSED array form the server. (I will send inputedValue as a parameter)

	    if(document.documentElement.clientWidth <= 600){
	    	console.log("Aaaaaaaaaaaaaaaaa");
		}else{
			var x = document.getElementById("searchDropDownResults");
			if (x.style.display === "block" ) {
				x.style.display = "none";
			}else if(x.style.display === "none" ) {
				x.style.display = "block";
			}else{
				x.style.display = "block";
			}
		}
	}
	  
	handleSubmit = (evt) => {
	    const { name, shareholders } = this.state;
	    alert(`Incorporated: ${name} with ${shareholders.length} shareholders`);
	}

	closeMenuDropDownMenu(){
		var x = document.getElementById("dropdown-content");
		x.style.display = "none";
	}

    render() {
    	let rows = [];

    	if(this.state.inputedValue !== ''){ 
	    	rows = items.map( item => {
				if(item.searchId.includes(this.state.inputedValue)){ 
					return( 		
						<div onClick={() => this.openSelectedBook(item)}>
							{item.title}
						</div>			
					)
				}
			})
		}

		return( 
			<div id="headerMenuWrapper"  onClick={() => this.closeMenuDropDownMenu()}> 
				
		        <input
			        type="text"
			        placeholder="  search"
			        onChange={this.handleNameChange}
			        className="searchFormField"
		        />
		        <button onClick={this.handleSubmit} className="searchFormButton cursorPointer"> Search </button>
				
		        {this.state.showSearchDropdown === true ? 
			        <div id="searchDropDownResults" className="dropdownSearchContent">
						<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownSearchText"> 
							{rows}
						</div>
					</div>
				:
					<div id="searchDropDownResults" className="dropdownSearchContentHide">
						<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownSearchText"> 
							{rows}
						</div>
					</div>
				}
				


			</div>
		)
    }
}

export default SearchForm;