import React, { Component } from 'react';
import settingsIcon from '../images/settingsIcon.png';
import profilePhoto from '../images/profilePhoto.png';
import readingIcon from '../images/readingIcon.png';
import wordListIcon from '../images/wordListIcon.png';
import dropDownIcon from '../images/dropDownIcon.png';
import hamburgerMenuIcon from '../images/hamburgerMenuIcon.png';
import demoIcon from '../images/demoIcon.png';

class HeaderMenu extends Component {

	constructor(props) {
	    super(props);
	    this.state = {
		    browserHeight: '700px',
	    };
	    this.headerMenuItemAction = this.headerMenuItemAction.bind(this);
	}

	headerMenuItemAction(what){
		console.log(what);
		if(what !== 'dropDownMenu'){
			this.closeDropDownMenu();
		}
	}

	closeDropDownMenu(){
		var x = document.getElementById("dropdown-content");
		x.style.display = "none";
	}

	myFunction() {
		if(document.documentElement.clientWidth <= 600){
			this.props.toggleWoleScreenDropDownMenu();
		}else{
			var x = document.getElementById("dropdown-content");
			if (x.style.display === "block" ) {
				x.style.display = "none";
			}else if(x.style.display === "none" ) {
				x.style.display = "block";
			}else{
				x.style.display = "block";
			}
		}
	}

    render() {
    	if(this.props.mode === 'big'){ 
			return( 
				<div id="headerMenuWrapper" style={{"float": "right"}} > 
					<div id="headerMenuDropDown" onClick={() => this.myFunction()} className="displayInlineBlock"> 
						
						<div className="dropdown">
							<img id="frontPageLogoImage" className="headerMenuIcon" src={dropDownIcon} />
							

							<div id="dropdown-content" className="dropdown-content">
								<div onClick={() => this.headerMenuItemAction('dropDownMenu')} className="dropDownMenuText"> 
									<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={demoIcon} /> <div className="headerDropDownText">statistics</div> 
								</div>
								<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
									<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={demoIcon} /> <div className="headerDropDownText">users</div>
								</div>
								<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
									<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={demoIcon} /> <div className="headerDropDownText">others</div>
								</div>
								<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
									<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={demoIcon} /> <div className="headerDropDownText">news</div>
								</div>
								<div onClick={() => this.headerMenuItemAction('smth1')} className="dropDownMenuText"> 
									<img id="frontPageLogoImage" className="headerMenuIconDropDown" src={demoIcon} /> <div className="headerDropDownText">recomendations</div>
								</div>
							</div>
						</div> 

					</div>
					<div id="headerMenuWordList" onClick={() => this.headerMenuItemAction('headerMenuWordList')} className="displayInlineBlock"> 
						<img id="frontPageLogoImage" className="headerMenuIcon" src={wordListIcon} /> 
					</div>
					<div id="headerMenuReading"  onClick={() => this.headerMenuItemAction('headerMenuReading')} className="displayInlineBlock circleOnProfilePhoto"> 
						<img id="frontPageLogoImage" className="headerMenuIcon" src={readingIcon} /> 
					</div>
					<div id="headerMenuProfilePhoto" onClick={() => this.headerMenuItemAction('headerMenuProfilePhoto')} className="displayInlineBlock"> 
						<img id="frontPageLogoImage" className="headerMenuIcon circleOnProfilePhoto" src={profilePhoto} /> 
					</div>
					<div id="headerMenuSettings" onClick={() => this.headerMenuItemAction('headerMenuSettings')} className="displayInlineBlock"> 
						<img id="frontPageLogoImage" className="headerMenuIcon" src={settingsIcon} /> 
					</div>
				</div>
			)
		}else{
			return( 
				<div id="headerMenuWrapper" style={{"float": "right"}} > 
					<div id="headerMenuDropDown" onClick={() => this.myFunction()} className="displayInlineBlock cursorPointer cursorPointer"> <img id="frontPageLogoImage" className="headerMenuIcon cursorPointer" src={hamburgerMenuIcon} /> </div>
						
				</div>
			)
		}
    }
}

export default HeaderMenu;